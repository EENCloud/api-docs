//
//  Target.swift
//  EENSDK-Demo-Swift
//
//  Created by Oana Corb on 01/05/2019.
//  Copyright © 2019 EagleEyeNetworks. All rights reserved.
//

import Moya

enum Environment {
	case production
	
	var url : String {
		switch self {
		case .production:
			return "https://login.eagleeyenetworks.com"
		}
	}
	
	var name : String {
		switch self {
		case .production:
			return "Production"
		}
	}
	
	var testUsername : String {
		switch self {
		case .production:
			return "demomobile@eagleeyenetworks.com"
			
		}
	}
	
	var testPassword : String {
		switch self {
		case .production:
			return "workingwell"
		}
	}
	
	var testCameraId : String {
		switch self {
		case .production:
			return "1000f60d"
		}
	}
	
	var testStartTimestamp : String {
		switch self {
		case .production:
			return "20190502030959.682"
		}
	}
	
	var testEndTimestamp : String {
		switch self {
		case .production:
			return "20190502031422.560"
		}
	}
}

enum Target {
	case authenticate(Environment, String, String)
	case authorize(Environment, String)
}

extension Target: TargetType {
	var baseURL: URL {
		switch self {
		case let .authenticate(environment, _, _):
			return URL(string: "\(environment.url)")!
		case let .authorize(environment, _):
			return URL(string: "\(environment.url)")!
		}
	}
	
	var path: String {
		switch self {
		case .authenticate:
			return "/g/aaa/authenticate"
		case .authorize:
			return "/g/aaa/authorize"
		}
	}
	
	var method: Moya.Method {
		switch self {
		case .authenticate:
			return .post
		case .authorize:
			return .post
		}
	}
	
	var parameters: [String: Any]? {
		switch self {
		case let .authenticate(_, username, password):
			return ["realm": "eagleeyenetworks", "username" : username, "password" : password]
		case let .authorize(_, token):
			return ["token": token]
		}
	}
	
	var parameterEncoding: ParameterEncoding {
		return URLEncoding.queryString
	}
	
	var sampleData: Data {
		return Data()
	}
	
	var task: Task {
		guard let parameters = parameters else {
			return .requestPlain
		}
		
		return .requestParameters(parameters: parameters, encoding: parameterEncoding)
	}
	
	var headers: [String: String]? {
		return nil
	}
}
