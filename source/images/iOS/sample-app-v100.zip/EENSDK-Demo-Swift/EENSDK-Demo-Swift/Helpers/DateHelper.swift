//
//  DateHelper.swift
//  EENSDK-Demo-Swift
//
//  Created by Oana Corb on 01/05/2019.
//  Copyright © 2019 EagleEyeNetworks. All rights reserved.
//

import Foundation

class DateHelper {
	
	public static func string(from date : Date) -> String {
		return DateHelper.dateFormatter().string(from: date)
	}
	
	public static func date(from string : String) -> Date {
		return DateHelper.dateFormatter().date(from: string) ?? Date()
	}
	
	private static func dateFormatter() -> DateFormatter {
		let formatter = DateFormatter.init()
		formatter.timeZone = TimeZone.init(identifier: "UTC")
		formatter.dateFormat = "yyyyMMddHHmmss.SSS"
		
		return formatter
	}
}
