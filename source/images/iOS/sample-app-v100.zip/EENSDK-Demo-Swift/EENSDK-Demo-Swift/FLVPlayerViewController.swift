//
//  FLVPlayerViewController.swift
//  EENSDK-Demo-Swift
//
//  Created by Oana Corb on 01/05/2019.
//  Copyright © 2019 EagleEyeNetworks. All rights reserved.
//

import UIKit
import EENSDK_iOS

class FLVPlayerViewController: UIViewController {
	
	private static let k_ApiKey = "2969a7b0-e130-11e3-92fc-123a277611f2"
	
	public var isHistorical : Bool?
	
	public var cluster : String?
	public var cameraId : String?
	
	public var startDate : Date?
	public var endDate : Date?
	
	private var mediaPlayer : EENMediaPlayer?
	private var currentItem : EENMediaItem?
	
	private var alert : UIAlertController?
	
	override func viewDidAppear(_ animated: Bool) {
		super.viewDidAppear(animated)
		
		requestStream()
	}
	
	override var prefersStatusBarHidden: Bool {
		return true
	}
	
	private func requestStream() {
		showAlert(with: "Establishing connection", action: nil)
		
		mediaPlayer = EENMediaPlayer()
		mediaPlayer?.delegate = self
		
		mediaPlayer?.showControlBar()
		
		if let mediaPlayer = mediaPlayer {
			mediaPlayer.frame = view.frame
			view.addSubview(mediaPlayer)
			
			if let cameraId = cameraId, let cluster = cluster {
				var builder = EENMediaItemBuilder.init()
				
				let baseUrl = "https://\(cluster).eagleeyenetworks.com"
				
				if isHistorical == true {
					if let startDate = startDate, let endDate = endDate {
						builder = EENMediaItemBuilder.init(forHistoricalItem: cameraId, baseUrl: baseUrl, start: startDate, end: endDate)
					}
				} else {
					builder = EENMediaItemBuilder.init(forLiveItem: cameraId, baseUrl: baseUrl)
				}
				
				if let timeZone = TimeZone.init(identifier: "US/Central") {
					builder.setTimeZone(timeZone)
				}
				
				builder.setApiKey(FLVPlayerViewController.k_ApiKey)
				
				currentItem = builder.build()
				if let currentItem = currentItem {
					mediaPlayer.start(with: currentItem)
				} else {
					showAlert(with: "Error loading stream", action: "OK")
				}
			} else {
				showAlert(with: "Error loading stream", action: "OK")
			}
		}
	}
	
	func showAlert(with message : String, action : String?) {
		hideAlert {
			self.alert = UIAlertController.init(title: "", message: message, preferredStyle: .alert)
			self.alert?.view.center = self.view.center
			
			if let action = action {
				let alertAction = UIAlertAction.init(title: action, style: .cancel, handler: { _ in
					self.dismiss(animated: true, completion: nil)
				})
				
				self.alert?.addAction(alertAction)
			}
			
			if let alert = self.alert {
				self.present(alert, animated: true, completion: nil)
			}
		}
	}
	
	func hideAlert() {
		DispatchQueue.main.async {
			if let alert = self.alert {
				alert.dismiss(animated: true, completion: nil)
			}
		}
	}
	
	func hideAlert(completion: (() -> Void)? = nil) {
		DispatchQueue.main.async {
			if let alert = self.alert {
				alert.dismiss(animated: true, completion: completion)
			} else {
				completion!()
			}
		}
	}
}

extension FLVPlayerViewController : EENMediaPlayerDelegate {
	func mediaPlayer(_ mediaPlayer: EENMediaPlayer, onStatusChanged newStatus: EENMediaPlayerStatus) {
		switch newStatus {
		case .unknown:
			showAlert(with: "Establishing connection", action: nil)
		case .failed:
			showAlert(with: mediaPlayer.failureReason.detailMessage ?? mediaPlayer.failureReason.generalMessage, action: "OK")
		default:
			hideAlert()
		}
	}
	
	func mediaPlayer(_ mediaPlayer: EENMediaPlayer, onPlaybackStateChanged newPlaybackState: EENMediaPlayerPlaybackState) {
		switch newPlaybackState {
		case .buffering:
			showAlert(with: "Buffering", action: nil)
		default:
			hideAlert()
		}
	}
	
	func mediaPlayerDonePressed(_ mediaPlayer: EENMediaPlayer) {
		self.dismiss(animated: true, completion: nil)
	}
}
