//
//  EENSDK_iOS.h
//  EENSDK-iOS
//
//  Created by D. Ianchyk on 19/11/2018.
//  Copyright © 2018 Eagle Eye Networks. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for EENSDK_iOS.
FOUNDATION_EXPORT double EENSDK_iOSVersionNumber;

//! Project version string for EENSDK_iOS.
FOUNDATION_EXPORT const unsigned char EENSDK_iOSVersionString[];

#import <EENSDK_iOS/EENMediaPlayer.h>
