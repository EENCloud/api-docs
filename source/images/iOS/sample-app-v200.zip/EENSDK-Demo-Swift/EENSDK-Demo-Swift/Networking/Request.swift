//
//  Helper.swift
//  EENSDK-Demo-Swift
//
//  Created by Oana Corb on 01/05/2019.
//  Copyright © 2019 EagleEyeNetworks. All rights reserved.
//

import Moya
import SwiftyJSON

class Request {
	static func authenticate(to environment: Environment, username: String, password: String,  completionClosure: @escaping (_ token: String?, _ error: String?) -> Void) {
		MoyaProvider<Target>().request(.authenticate(environment, username, password)) { result in
			switch result {
			case .success(let response):
				guard let _ = try? response.filterSuccessfulStatusCodes() else {
					completionClosure(nil, "Authenticate request failed with code: \(response.statusCode)")
					return
				}
				
				guard let json = try? JSON(data: response.data), let tokenValue = json["token"].string else {
					completionClosure(nil, "Can't parse response from server")
					return
				}
				
				completionClosure(tokenValue, nil)
			case .failure(let error) :
				completionClosure(nil, error.errorDescription)
			}
		}
	}
	
	static func authorize(with environment: Environment, token: String, completionClosure: @escaping (_ cluster: String?, _ error: String?) -> Void) {
		MoyaProvider<Target>().request(.authorize(environment, token)) { result in
			switch result {
			case .success(let response):
				guard let _ = try? response.filterSuccessfulStatusCodes() else {
					completionClosure(nil, "Authorize request failed with code: \(response.statusCode)")
					return
				}
				
				guard let json = try? JSON(data: response.data), let cluster = json["active_brand_subdomain"].string else {
					completionClosure(nil, "Can't parse response from server")
					return
				}
				
				completionClosure(cluster, nil)
			case .failure(let error) :
				completionClosure(nil, error.errorDescription)
			}
		}
	}
}
