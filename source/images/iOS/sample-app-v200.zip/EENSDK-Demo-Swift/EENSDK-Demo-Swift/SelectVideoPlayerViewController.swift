//
//  SelectVideoPlayerViewController.swift
//  EENSDK-Demo-Swift
//
//  Created by Oana Corb on 01/05/2019.
//  Copyright © 2019 EagleEyeNetworks. All rights reserved.
//

import UIKit

class SelectVideoPlayerViewController: UIViewController {
	
	private static let environment : Environment = .production
	
	public var cluster : String?
	
	private var isHistorical : Bool?
	
	private var cameraId : String = SelectVideoPlayerViewController.environment.testCameraId
	
	private var startDate : Date?
	private var endDate : Date?
	
	@IBOutlet weak var startTimestampTextField: UITextField!
	@IBOutlet weak var endTimestampTextField: UITextField!
	@IBOutlet weak var cameraIdTextField: UITextField!

	override func viewDidLoad() {
		super.viewDidLoad()
		
		startTimestampTextField.text = SelectVideoPlayerViewController.environment.testStartTimestamp
		endTimestampTextField.text = SelectVideoPlayerViewController.environment.testEndTimestamp
		cameraIdTextField.text = SelectVideoPlayerViewController.environment.testCameraId
	}
	
	override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
		if segue.identifier == "fromSelectVideoPlayerToFLVPlayerDefaultUI" || segue.identifier == "fromSelectVideoPlayerToFLVPlayerCustomUI" {
			let flvPlayerVC = segue.destination as! FLVPlayerViewController
			flvPlayerVC.cluster = cluster ?? ""
			flvPlayerVC.isHistorical = isHistorical
			flvPlayerVC.cameraId = cameraId
			flvPlayerVC.startDate = startDate
			flvPlayerVC.endDate = endDate
		}
	}
	
	@IBAction func liveStreamDefaultUIButtonTapped(_ sender: Any) {
		if cluster != nil {
			isHistorical = false
			cameraId = cameraIdTextField.text ?? SelectVideoPlayerViewController.environment.testCameraId
			
			performSegue(withIdentifier: "fromSelectVideoPlayerToFLVPlayerDefaultUI", sender: self)
		}
	}
	
	@IBAction func liveStreamCustomUIButtonTapped(_ sender: Any) {
		if cluster != nil {
			isHistorical = false
			cameraId = cameraIdTextField.text ?? SelectVideoPlayerViewController.environment.testCameraId
			
			performSegue(withIdentifier: "fromSelectVideoPlayerToFLVPlayerCustomUI", sender: self)
		}
	}
	
	@IBAction func historicalStreamDefaultUIButtonTapped(_ sender: Any) {
		if cluster != nil {
			let startTimestamp = startTimestampTextField.text ?? SelectVideoPlayerViewController.environment.testStartTimestamp
			let endTimestamp = endTimestampTextField.text ?? SelectVideoPlayerViewController.environment.testEndTimestamp
			
			isHistorical = true
			cameraId = cameraIdTextField.text ?? SelectVideoPlayerViewController.environment.testCameraId
			startDate = DateHelper.date(from: startTimestamp)
			endDate = DateHelper.date(from: endTimestamp)
			
			performSegue(withIdentifier: "fromSelectVideoPlayerToFLVPlayerDefaultUI", sender: self)
		}
	}
	
	@IBAction func historicalStreamCustomUIButtonTapped(_ sender: Any) {
		if cluster != nil {
			let startTimestamp = startTimestampTextField.text ?? SelectVideoPlayerViewController.environment.testStartTimestamp
			let endTimestamp = endTimestampTextField.text ?? SelectVideoPlayerViewController.environment.testEndTimestamp
			
			isHistorical = true
			cameraId = cameraIdTextField.text ?? SelectVideoPlayerViewController.environment.testCameraId
			startDate = DateHelper.date(from: startTimestamp)
			endDate = DateHelper.date(from: endTimestamp)
			
			performSegue(withIdentifier: "fromSelectVideoPlayerToFLVPlayerCustomUI", sender: self)
		}
	}
}
