//
//  FLVPlayerCustomUIViewController.swift
//  EENSDK-Demo-Swift
//
//  Created by Oana Corb on 20/05/2019.
//  Copyright © 2019 EagleEyeNetworks. All rights reserved.
//

import UIKit
import EENSDK_iOS

class FLVPlayerCustomUIViewController: FLVPlayerViewController {
	
	@IBOutlet weak var playPauseButton: UIButton!
	
	@IBAction func playPauseButtonTapped(_ sender: Any) {
		playPauseButton.isSelected = !playPauseButton.isSelected
		playPauseButton.isSelected ? play() : pause()
	}
	
	@IBAction func stopButtonTapped(_ sender: Any) {
		stopPlayer()
	}
	
	@IBAction func doneButtonTapped(_ sender: Any) {
		self.dismiss(animated: true, completion: nil)
	}
	
	override func shouldShowControlBar() -> Bool {
		return false
	}
	
	override func mediaPlayer(_ mediaPlayer: EENMediaPlayer, onStatusChanged newStatus: EENMediaPlayerStatus) {
		switch newStatus {
		case .unknown:
			self.playPauseButton.isSelected = false
			showAlert(with: "Establishing connection", action: nil)
		case .failed:
			self.playPauseButton.isSelected = false
			showAlert(with: mediaPlayer.failureReason.detailMessage ?? mediaPlayer.failureReason.generalMessage, action: "OK")
		default:
			hideAlert()
		}
	}
	
	override func mediaPlayer(_ mediaPlayer: EENMediaPlayer, onPlaybackStateChanged newPlaybackState: EENMediaPlayerPlaybackState) {
		hideAlert()
		switch newPlaybackState {
		case .playing:
			self.playPauseButton.isSelected = true
		case .paused:
			self.playPauseButton.isSelected = false
		case .buffering:
			showAlert(with: "Buffering", action: nil)
		default:
			hideAlert()
		}
	}
	
}
