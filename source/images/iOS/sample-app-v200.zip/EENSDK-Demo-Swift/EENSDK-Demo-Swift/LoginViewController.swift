//
//  ViewController.swift
//  EENSDK-Demo-Swift
//
//  Created by Oana Corb on 01/05/2019.
//  Copyright © 2019 EagleEyeNetworks. All rights reserved.
//

import UIKit
import Alamofire

class LoginViewController: UIViewController {
	
	private static let environment : Environment = .production
	
	private var cluster : String?

	@IBOutlet weak var usernameTextField: UITextField!
	@IBOutlet weak var passwordTextField: UITextField!
	@IBOutlet weak var errorLabel: UILabel!
	
	@IBOutlet weak var loginButton: UIButton!
	@IBOutlet weak var loadingSpinner: UIActivityIndicatorView!
	
	override func viewDidLoad() {
		super.viewDidLoad()
		
		usernameTextField.text = LoginViewController.environment.testUsername
		passwordTextField.text = LoginViewController.environment.testPassword
		
		stopLoginAnimation()
	}
	
	override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
		if segue.identifier == "fromLoginToSelectVideoPlayer" {
			let selectVideoPlayerVC = segue.destination as! SelectVideoPlayerViewController
			selectVideoPlayerVC.cluster = cluster
		}
	}
	
	@IBAction func loginButtonTapped(_ sender: Any) {
		errorLabel.isHidden = true
		startLoginAnimation()
		
		Request.authenticate(to: LoginViewController.environment, username: usernameTextField.text ?? LoginViewController.environment.testUsername, password: passwordTextField.text ?? LoginViewController.environment.testPassword) { [weak self] token, error in
			if let error = error {
				self?.show(error: error)
			} else if let token = token {
				Request.authorize(with: LoginViewController.environment, token: token) { [weak self] cluster, error in
					if let error = error {
						self?.show(error: error)
					} else if let cluster = cluster {
						self?.successfullLogin(to: cluster)
					}
				}
			}
		}
	}
	
	@IBAction func showPasswordButtonTapped(_ sender: Any) {
		passwordTextField.isSecureTextEntry.toggle()
	}
	
	private func show(error : String) {
		print("Error \(error)")
		
		errorLabel.isHidden = false
		errorLabel.text = error
		
		stopLoginAnimation()
	}
	
	private func startLoginAnimation() {
		loginButton.isHidden = true
		loadingSpinner.isHidden = false
		loadingSpinner.startAnimating()
	}
	
	private func stopLoginAnimation() {
		loginButton.isHidden = false
		loadingSpinner.isHidden = true
		loadingSpinner.stopAnimating()
	}
	
	private func successfullLogin(to cluster : String) {
		stopLoginAnimation()
		
		self.cluster = cluster
		performSegue(withIdentifier: "fromLoginToSelectVideoPlayer", sender: self)
	}
}

