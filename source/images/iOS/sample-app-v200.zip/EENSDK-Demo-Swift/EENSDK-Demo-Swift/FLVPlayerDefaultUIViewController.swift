//
//  FLVPlayerDefaultUIViewController.swift
//  EENSDK-Demo-Swift
//
//  Created by Oana Corb on 01/05/2019.
//  Copyright © 2019 EagleEyeNetworks. All rights reserved.
//

import UIKit
import EENSDK_iOS

class FLVPlayerDefaultUIViewController: FLVPlayerViewController {}
