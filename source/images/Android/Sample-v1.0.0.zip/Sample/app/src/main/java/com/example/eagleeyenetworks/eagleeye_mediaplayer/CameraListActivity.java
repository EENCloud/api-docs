package com.example.eagleeyenetworks.eagleeye_mediaplayer;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.example.eagleeyenetworks.eagleeye_mediaplayer.models.EENListDevice;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;

public class CameraListActivity extends AppCompatActivity
{

	///////////////////////////////////////////////////////////////////////////////////////////////
	//
	// Constants
	//
	///////////////////////////////////////////////////////////////////////////////////////////////

	private static final String TAG = "CameraListActivity";

	private static final String EXTRA_AUTH_TOKEN = "auth_token";
	private static final String EXTRA_DEVICE_LIST = "device_list";

	///////////////////////////////////////////////////////////////////////////////////////////////
	//
	// Static
	//
	///////////////////////////////////////////////////////////////////////////////////////////////

	public static Intent newInstance( Context context, String authToken, String deviceList )
	{
		final Intent intent = new Intent( context, CameraListActivity.class );
		intent.putExtra( EXTRA_AUTH_TOKEN, authToken );
		intent.putExtra( EXTRA_DEVICE_LIST, deviceList );
		return intent;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////
	//
	// Fields
	//
	///////////////////////////////////////////////////////////////////////////////////////////////

	private String _authToken;
	private ArrayList< EENListDevice > _cameras;

	private ListView _camerasListView;
	private ArrayAdapter< EENListDevice > _camerasAdapter;

	///////////////////////////////////////////////////////////////////////////////////////////////
	//
	// Public methods
	//
	///////////////////////////////////////////////////////////////////////////////////////////////

	@Override
	protected void onCreate( Bundle savedInstanceState )
	{
		super.onCreate( savedInstanceState );
		setContentView( R.layout.activity_camera_list );

		_authToken = getIntent().getStringExtra( EXTRA_AUTH_TOKEN );

		AsyncTask.execute( new Runnable()
		{
			@Override
			public void run()
			{
				parseDeviceList();
			}
		} );

		_camerasListView = findViewById( R.id.lv_cameras );
		_camerasListView.setOnItemClickListener( new AdapterView.OnItemClickListener()
		{
			@Override
			public void onItemClick( AdapterView< ? > parent, View view, int position, long id )
			{
				final EENListDevice device = _camerasAdapter.getItem( position );
				if ( device == null )
				{
					return;
				}

				startActivity( VideoPlayerActivity.newInstance( CameraListActivity.this, _authToken, device.cameraId ) );
			}
		} );
	}

	///////////////////////////////////////////////////////////////////////////////////////////////
	//
	// Private methods
	//
	///////////////////////////////////////////////////////////////////////////////////////////////

	private void parseDeviceList()
	{
		try
		{
			_cameras = new ArrayList<>();

			final JSONArray deviceList = new JSONArray( getIntent().getStringExtra( EXTRA_DEVICE_LIST ) );
			JSONArray entry;
			String cameraId, name, type;
			for ( int i = 0; i < deviceList.length(); i++ )
			{
				entry = deviceList.getJSONArray( i );
				cameraId = entry.getString( 1 );
				name = entry.getString( 2 );
				type = entry.getString( 3 );

				final EENListDevice device = new EENListDevice( cameraId, name, type );
				if ( device.isCamera() )
				{
					_cameras.add( device );
				}
			}

			runOnUiThread( new Runnable()
			{
				@Override
				public void run()
				{
					_camerasAdapter = new ArrayAdapter<>( CameraListActivity.this, android.R.layout.simple_list_item_1, _cameras );
					_camerasListView.setAdapter( _camerasAdapter );
				}
			} );

		}
		catch ( JSONException ex )
		{
			Log.e( TAG, "parseDeviceList()::Failed", ex );
		}
	}
}
