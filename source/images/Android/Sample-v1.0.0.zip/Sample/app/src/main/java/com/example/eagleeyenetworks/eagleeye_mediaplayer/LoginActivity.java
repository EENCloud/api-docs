package com.example.eagleeyenetworks.eagleeye_mediaplayer;

import android.support.annotation.NonNull;
import android.support.annotation.StringRes;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Cookie;
import okhttp3.CookieJar;
import okhttp3.FormBody;
import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class LoginActivity extends AppCompatActivity
{

	///////////////////////////////////////////////////////////////////////////////////////////////
	//
	// Constants
	//
	///////////////////////////////////////////////////////////////////////////////////////////////

	private static final String TAG = "LoginActivity";

	private static final int MIN_PASSWORD_LENGTH = 6;

	///////////////////////////////////////////////////////////////////////////////////////////////
	//
	// Fields
	//
	///////////////////////////////////////////////////////////////////////////////////////////////

	private EditText _emailInput;
	private EditText _passwordInput;

	private OkHttpClient _httpClient;
	private final EENCookieJar _cookieJar = new EENCookieJar();

	///////////////////////////////////////////////////////////////////////////////////////////////
	//
	// Public methods
	//
	///////////////////////////////////////////////////////////////////////////////////////////////

	@Override
	protected void onCreate( Bundle savedInstanceState )
	{
		super.onCreate( savedInstanceState );
		setContentView( R.layout.activity_login );

		_emailInput = findViewById( R.id.et_email );
		_passwordInput = findViewById( R.id.et_password );

		// Quick hack
		_httpClient = new OkHttpClient.Builder().cookieJar( _cookieJar ).build();
	}

	public void submitClicked( View button )
	{
		final String user = _emailInput.getText().toString();
		final String pass = _passwordInput.getText().toString();

		if ( !Patterns.EMAIL_ADDRESS.matcher( user ).matches() )
		{
			showError( R.string.invalid_email );
			return;
		}

		if ( pass.length() < MIN_PASSWORD_LENGTH )
		{
			showError( R.string.pass_too_short );
			return;
		}

		authenticate( user, pass );
	}

	///////////////////////////////////////////////////////////////////////////////////////////////
	//
	// Private methods
	//
	///////////////////////////////////////////////////////////////////////////////////////////////

	private void showError( @StringRes final int errorStrId )
	{
		runOnUiThread( new Runnable()
		{
			@Override
			public void run()
			{
				Toast.makeText( LoginActivity.this, errorStrId, Toast.LENGTH_SHORT ).show();
			}
		} );
	}

	private void authenticate( String user, String pass )
	{
		final RequestBody payload = new FormBody.Builder().add( "username", user ).add( "password", pass ).add( "realm", "eagleeyenetworks" ).build();
		final Request authRequest = new Request.Builder().url( "https://login.eagleeyenetworks.com/g/aaa/authenticate" ).method( "POST", payload ).build();
		_httpClient.newCall( authRequest ).enqueue( new Callback()
		{
			@Override
			public void onFailure( @NonNull Call call, @NonNull IOException ex )
			{
				showError( R.string.server_error );
			}

			@Override
			public void onResponse( @NonNull Call call, @NonNull Response response ) throws IOException
			{
				if ( response.body() == null )
				{
					showError( R.string.server_error );
					return;
				}

				switch ( response.code() )
				{
					case 200:
						try
						{
							JSONObject responseObject = new JSONObject( response.body().string() );
							authorize( responseObject.getString( "token" ) );
						}
						catch ( JSONException ex )
						{
							Log.e( TAG, "authenticate()::Failed", ex );
						}
						break;

					case 401:
						showError( R.string.invalid_user_or_pass );
						break;

					default:
						showError( R.string.server_error );
						break;
				}
			}
		} );
	}

	private void authorize( String token )
	{
		final RequestBody payload = new FormBody.Builder().add( "token", token ).build();
		final Request request = new Request.Builder().url( "https://login.eagleeyenetworks.com/g/aaa/authorize" ).method( "POST", payload ).build();
		_httpClient.newCall( request ).enqueue( new Callback()
		{
			@Override
			public void onFailure( @NonNull Call call, @NonNull IOException ex )
			{
				showError( R.string.server_error );
			}

			@Override
			public void onResponse( @NonNull Call call, @NonNull Response response ) throws IOException
			{
				if ( response.code() == 200 )
				{
					fetchDevices();
				}
				else
				{
					showError( R.string.server_error );
				}
			}
		} );
	}

	private void fetchDevices()
	{
		final Request fetchDevices = new Request.Builder().url( "https://login.eagleeyenetworks.com/g/list/devices" ).build();
		_httpClient.newCall( fetchDevices ).enqueue( new Callback()
		{
			@Override
			public void onFailure( @NonNull Call call, @NonNull IOException ex )
			{
				showError( R.string.server_error );
			}

			@Override
			public void onResponse( @NonNull Call call, @NonNull Response response ) throws IOException
			{
				if ( response.body() == null )
				{
					showError( R.string.server_error );
					return;
				}

				if ( response.code() == 200 )
				{
					startActivity( CameraListActivity.newInstance( LoginActivity.this, _cookieJar.getAuthToken(), response.body().string() ) );
				}
				else
				{
					showError( R.string.server_error );
				}
			}
		} );
	}

	///////////////////////////////////////////////////////////////////////////////////////////////
	//
	// Inner class
	//
	///////////////////////////////////////////////////////////////////////////////////////////////

	private class EENCookieJar implements CookieJar
	{

		///////////////////////////////////////////////////////////////////////////////////////////////
		//
		// Fields
		//
		///////////////////////////////////////////////////////////////////////////////////////////////

		private List< Cookie > _cookies;

		///////////////////////////////////////////////////////////////////////////////////////////////
		//
		// Public methods
		//
		///////////////////////////////////////////////////////////////////////////////////////////////

		@Override
		public void saveFromResponse( @NonNull HttpUrl url, @NonNull List< Cookie > cookies )
		{
			if ( cookies.size() > 0 )
			{
				_cookies = cookies;
			}
		}

		@NonNull
		@Override
		public List< Cookie > loadForRequest( @NonNull HttpUrl url )
		{
			if ( _cookies != null )
			{
				return _cookies;
			}
			return new ArrayList<>();
		}

		///////////////////////////////////////////////////////////////////////////////////////////////
		//
		// Private methods
		//
		///////////////////////////////////////////////////////////////////////////////////////////////

		private String getAuthToken()
		{
			for ( Cookie cookie : _cookies )
			{
				if ( cookie.name().equalsIgnoreCase( "auth_key" ) )
				{
					return cookie.value();
				}
			}
			return "";
		}
	}

}
