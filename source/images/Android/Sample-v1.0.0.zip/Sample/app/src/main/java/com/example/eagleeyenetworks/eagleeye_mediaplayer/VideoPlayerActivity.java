package com.example.eagleeyenetworks.eagleeye_mediaplayer;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.widget.FrameLayout;
import android.widget.Toast;

import com.een.eensdk.android.listener.EENMediaPlayerListener;
import com.een.eensdk.android.model.EENMediaItem;
import com.een.eensdk.android.model.EENMediaPlayerPlaybackState;
import com.een.eensdk.android.model.EENMediaPlayerStatus;
import com.een.eensdk.android.player.EENMediaPlayer;

import java.util.Date;

public class VideoPlayerActivity extends AppCompatActivity implements EENMediaPlayerListener
{

	///////////////////////////////////////////////////////////////////////////////////////////////
	//
	// Constants
	//
	///////////////////////////////////////////////////////////////////////////////////////////////

	private static final String TAG = "VideoPlayerActivity";

	private static final String EXTRA_AUTH_TOKEN = "auth_token";
	private static final String EXTRA_CAMERA_ID = "camera_id";

	///////////////////////////////////////////////////////////////////////////////////////////////
	//
	// Static
	//
	///////////////////////////////////////////////////////////////////////////////////////////////

	public static Intent newInstance( Context context, String authToken, String cameraId )
	{
		final Intent intent = new Intent( context, VideoPlayerActivity.class );
		intent.putExtra( EXTRA_AUTH_TOKEN, authToken );
		intent.putExtra( EXTRA_CAMERA_ID, cameraId );
		return intent;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////
	//
	// Fields
	//
	///////////////////////////////////////////////////////////////////////////////////////////////

	private EENMediaPlayer _player;

	///////////////////////////////////////////////////////////////////////////////////////////////
	//
	// Public methods
	//
	///////////////////////////////////////////////////////////////////////////////////////////////

	@Override
	protected void onCreate( Bundle savedInstanceState )
	{
		super.onCreate( savedInstanceState );
		setContentView( R.layout.activity_video_player );

		final String authToken = getIntent().getStringExtra( EXTRA_AUTH_TOKEN );
		final String cameraId = getIntent().getStringExtra( EXTRA_CAMERA_ID );

		final FrameLayout playerHolder = findViewById( R.id.holder_player );

		if ( _player == null )
		{
			_player = new EENMediaPlayer( this );
			_player.setListener( this );
		}

		FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams( FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT );
		layoutParams.gravity = Gravity.CENTER;
		playerHolder.addView( _player, layoutParams );

		final String subDomain = authToken.substring( 0, authToken.indexOf( '~' ) );
		final String videoExt = "flv";
		final String urlFormat = "https://%s.eagleeyenetworks.com/asset/play/video.%s?A=%s";
		final String videoUrl = String.format( urlFormat, subDomain, videoExt, authToken );

		final String apiKey = "YOUR API KEY HERE";

		/* Live item */
		_player.startWithMediaItem( EENMediaItem.Builder.builderForLiveItem( cameraId, videoUrl ).setApiKey( apiKey ).setTitle( "LIVE" ).build() );

		/* Historical item */
		/*_player.startWithMediaItem( EENMediaItem.Builder.builderForHistoricalItem( cameraId,
																				   videoUrl,
																				   new Date( System.currentTimeMillis() - 5 * 60 * 1_000L ),
																				   new Date( System.currentTimeMillis() - 60 * 1_000L ) )
														.setApiKey( apiKey )
														.setTitle( "REC" )
														.build() );*/

		_player.showControlBar();
	}

	@Override
	protected void onPause()
	{
		super.onPause();

		if ( _player != null )
		{
			_player.release();
			_player = null;
		}
	}

	// region EENMediaPlayerListener

	@Override
	public void onStatusChanged( EENMediaPlayer eenMediaPlayer, final EENMediaPlayerStatus eenMediaPlayerStatus )
	{
		Log.i( TAG, "onStatusChanged()::" + eenMediaPlayerStatus );
		runOnUiThread( new Runnable()
		{
			@Override
			public void run()
			{
				switch ( eenMediaPlayerStatus )
				{
					case ReadyToPlay:
						Toast.makeText( VideoPlayerActivity.this, "Streamer is ready to play", Toast.LENGTH_SHORT ).show();
						break;

					case Failed:
						Toast.makeText( VideoPlayerActivity.this, _player.getFailureReason().getDetailedReason(), Toast.LENGTH_SHORT ).show();
						break;

					default:
						break;
				}
			}
		} );
	}

	@Override
	public void onPlaybackStateChanged( final EENMediaPlayer eenMediaPlayer, final EENMediaPlayerPlaybackState eenMediaPlayerPlaybackState )
	{
		Log.i( TAG, "onPlaybackStateChanged()::" + eenMediaPlayerPlaybackState );
		runOnUiThread( new Runnable()
		{
			@Override
			public void run()
			{
				switch ( eenMediaPlayerPlaybackState )
				{
					case Playing:
						eenMediaPlayer.hideControlBar();
						break;

					case Paused:
						eenMediaPlayer.showControlBar();
						break;

					case Buffering:
						Toast.makeText( VideoPlayerActivity.this, "Buffering...", Toast.LENGTH_LONG ).show();
						break;
				}
			}
		} );
	}

	@Override
	public void donePressed( EENMediaPlayer eenMediaPlayer )
	{
		Log.i( TAG, "donePressed()::" );
	}

	// endregion EENMediaPlayerListener

}