package com.example.eagleeyenetworks.eagleeye_mediaplayer;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.een.eensdk.android.listener.EENMediaPlayerListener;
import com.een.eensdk.android.model.EENMediaItem;
import com.een.eensdk.android.model.EENMediaPlayerPlaybackState;
import com.een.eensdk.android.model.EENMediaPlayerStatus;
import com.een.eensdk.android.player.EENMediaPlayer;

import java.util.Date;

public class VideoPlayerActivity extends AppCompatActivity implements EENMediaPlayerListener
{

	///////////////////////////////////////////////////////////////////////////////////////////////
	//
	// Constants
	//
	///////////////////////////////////////////////////////////////////////////////////////////////

	private static final String TAG = "VideoPlayerActivity";

	private static final String EXTRA_AUTH_TOKEN = "auth_token";
	private static final String EXTRA_CAMERA_ID = "camera_id";

	///////////////////////////////////////////////////////////////////////////////////////////////
	//
	// Static
	//
	///////////////////////////////////////////////////////////////////////////////////////////////

	public static Intent newInstance( Context context, String authToken, String cameraId )
	{
		final Intent intent = new Intent( context, VideoPlayerActivity.class );
		intent.putExtra( EXTRA_AUTH_TOKEN, authToken );
		intent.putExtra( EXTRA_CAMERA_ID, cameraId );
		return intent;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////
	//
	// Fields
	//
	///////////////////////////////////////////////////////////////////////////////////////////////

	private EENMediaPlayer _player;

	private FrameLayout _playerHolder;
	private LinearLayout _optionsContainer;
	private LinearLayout _controlsContainer;

	///////////////////////////////////////////////////////////////////////////////////////////////
	//
	// Public methods
	//
	///////////////////////////////////////////////////////////////////////////////////////////////

	@Override
	protected void onCreate( Bundle savedInstanceState )
	{
		super.onCreate( savedInstanceState );
		setContentView( R.layout.activity_video_player );

		_playerHolder = findViewById( R.id.holder_player );
		_optionsContainer = findViewById( R.id.container_options );
		_controlsContainer = findViewById( R.id.container_controls );
	}

	@Override
	protected void onPause()
	{
		super.onPause();

		resetViews();
	}

	// region Options

	public void onLiveDefault( View v )
	{
		startStream( true, false );
	}

	public void onLiveCustom( View v )
	{
		startStream( true, true );
	}

	public void onHistoricalDefault( View v )
	{
		startStream( false, false );
	}

	public void onHistoricalCustom( View v )
	{
		startStream( false, true );
	}

	// endregion Options

	// region Controls

	public void onPlay( View v )
	{
		_player.play();
	}

	public void onPause( View v )
	{
		_player.pause();
	}

	public void onDestroy( View v )
	{
		resetViews();
	}

	// endregion Controls

	// region EENMediaPlayerListener

	@Override
	public void onStatusChanged( EENMediaPlayer eenMediaPlayer, final EENMediaPlayerStatus eenMediaPlayerStatus )
	{
		Log.i( TAG, "onStatusChanged()::" + eenMediaPlayerStatus );
		runOnUiThread( new Runnable()
		{
			@Override
			public void run()
			{
				switch ( eenMediaPlayerStatus )
				{
					case ReadyToPlay:
						Toast.makeText( VideoPlayerActivity.this, "Streamer is ready to play", Toast.LENGTH_SHORT ).show();
						break;

					case Failed:
						Toast.makeText( VideoPlayerActivity.this, _player.getFailureReason().getDetailedReason(), Toast.LENGTH_SHORT ).show();
						break;

					default:
						break;
				}
			}
		} );
	}

	@Override
	public void onPlaybackStateChanged( final EENMediaPlayer eenMediaPlayer, final EENMediaPlayerPlaybackState eenMediaPlayerPlaybackState )
	{
		Log.i( TAG, "onPlaybackStateChanged()::" + eenMediaPlayerPlaybackState );
		runOnUiThread( new Runnable()
		{
			@Override
			public void run()
			{
				switch ( eenMediaPlayerPlaybackState )
				{
					case Playing:
						Toast.makeText( VideoPlayerActivity.this, "Playing...", Toast.LENGTH_LONG ).show();
						break;

					case Paused:
						Toast.makeText( VideoPlayerActivity.this, "Paused...", Toast.LENGTH_LONG ).show();
						break;

					case Buffering:
						Toast.makeText( VideoPlayerActivity.this, "Buffering...", Toast.LENGTH_LONG ).show();
						break;
				}
			}
		} );
	}

	@Override
	public void donePressed( EENMediaPlayer eenMediaPlayer )
	{
		Log.i( TAG, "donePressed()::" );
		resetViews();
	}

	// endregion EENMediaPlayerListener

	private void startStream( boolean live, boolean custom )
	{
		_optionsContainer.setVisibility( View.GONE );

		final String authToken = getIntent().getStringExtra( EXTRA_AUTH_TOKEN );
		final String cameraId = getIntent().getStringExtra( EXTRA_CAMERA_ID );

		if ( _player != null )
		{
			_player.destroy();
			_player = null;
		}

		_player = new EENMediaPlayer( this );
		_player.setListener( this );

		FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams( FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT );
		layoutParams.gravity = Gravity.CENTER;
		_playerHolder.addView( _player, layoutParams );

		final String subDomain = authToken.substring( 0, authToken.indexOf( '~' ) );
		final String videoExt = "flv";
		final String urlFormat = "https://%s.eagleeyenetworks.com/asset/play/video.%s?A=%s";
		final String videoUrl = String.format( urlFormat, subDomain, videoExt, authToken );

		final String apiKey = "YOUR API KEY HERE";

		if ( live )
		{
			/* Live item */
			_player.startWithMediaItem( EENMediaItem.Builder.builderForLiveItem( cameraId, videoUrl ).setApiKey( apiKey ).setTitle( "LIVE" ).build() );
		}
		else
		{
			/* Historical item */
			_player.startWithMediaItem( EENMediaItem.Builder.builderForHistoricalItem( cameraId,
																					   videoUrl,
																					   new Date( System.currentTimeMillis() - 5 * 60 * 1_000L ),
																					   new Date( System.currentTimeMillis() - 60 * 1_000L ) )
															.setApiKey( apiKey )
															.setTitle( "REC" )
															.build() );
		}

		if ( custom )
		{
			_controlsContainer.setVisibility( View.VISIBLE );
		}
		else
		{
			_player.showControlBar();
		}
	}

	private void resetViews()
	{
		if ( _player != null )
		{
			_playerHolder.removeView( _player );

			_player.destroy();
			_player = null;
		}

		_optionsContainer.setVisibility( View.VISIBLE );
		_controlsContainer.setVisibility( View.GONE );
	}

}